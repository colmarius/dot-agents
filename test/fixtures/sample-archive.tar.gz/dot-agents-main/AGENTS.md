# Test Project Instructions

This is a mock AGENTS.md for testing.

## Commands

```bash
# Test command
echo "hello"
```
