# AGENTS.md template
