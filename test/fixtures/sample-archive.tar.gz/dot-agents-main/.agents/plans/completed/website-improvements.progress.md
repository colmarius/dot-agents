# Progress: Website Improvements

## Task 1: Add OG meta tags for link previews

**Thread**: https://ampcode.com/threads/T-019c25a3-5f40-75a7-a0e2-c28e75b5800e
**Status**: completed
**Iteration**: 1

### Changes

- `site/index.html` - Added OpenGraph tags (og:type, og:url, og:title, og:description), Twitter card tags, and canonical URL

### Commands Run

- Visual verification ✓

### Next

- Task 2: Add trust/security section near install command

---

## Task 2: Add trust/security section near install command

**Thread**: https://ampcode.com/threads/T-019c25a3-5f40-75a7-a0e2-c28e75b5800e
**Status**: completed
**Iteration**: 1

### Changes

- `site/index.html` - Added "Review first:" hint with curl | less command below install block
- `site/style.css` - Added styling for .install-hint and its code element

### Commands Run

- Visual verification ✓

### Next

- Task 3: Add "Pin a version" example

---

## Task 3: Add "Pin a version" example

**Thread**: https://ampcode.com/threads/T-019c25a3-5f40-75a7-a0e2-c28e75b5800e
**Status**: completed
**Iteration**: 1

### Changes

- `site/index.html` - Added collapsible details element with pinned version command
- `site/style.css` - Added styling for .install-details

### Commands Run

- Visual verification ✓

### Next

- Task 4: Add "What gets installed" directory tree section

---

## Task 4: Add "What gets installed" directory tree section

**Thread**: https://ampcode.com/threads/T-019c25a3-5f40-75a7-a0e2-c28e75b5800e
**Status**: completed
**Iteration**: 1

### Changes

- `site/index.html` - Added "What you get" section with directory tree
- `site/style.css` - Added styles for .what-you-get, .tree-block, and .tree-comment

### Commands Run

- Visual verification ✓

### Next

- Task 5: Add Quickstart 5-step recipe section

---

## Task 5: Add Quickstart 5-step recipe section

**Thread**: https://ampcode.com/threads/T-019c25a3-5f40-75a7-a0e2-c28e75b5800e
**Status**: completed
**Iteration**: 1

### Changes

- `site/index.html` - Added "Get started in 5 steps" section with actionable commands
- `site/style.css` - Added styles for .quickstart, .qs-step, .qs-num, .qs-content

### Commands Run

- Visual verification ✓

### Next

- Task 6: Clarify Ralph/Amp terminology in feature cards

---

## Task 6: Clarify Ralph/Amp terminology in feature cards

**Thread**: https://ampcode.com/threads/T-019c25a5-f588-721b-a09c-c0f878b50860
**Status**: completed
**Iteration**: 2

### Changes

- `site/index.html` - Renamed "Ralph Loops" to "Autonomous Execution (Ralph)" with link to glossary; removed "Ralph-ready" from "Structured Plans" card
- `site/style.css` - Added styling for `.term` span and its link

### Commands Run

- ./scripts/lint.sh ✓

### Next

- Task 7: Update CTA section with Quickstart button

---

## Task 7: Update CTA section with Quickstart button

**Thread**: https://ampcode.com/threads/T-019c25a5-f588-721b-a09c-c0f878b50860
**Status**: completed
**Iteration**: 2

### Changes

- `site/index.html` - Reordered CTA buttons: Quickstart (primary) | Full Docs | GitHub
- `site/style.css` - Added `.btn-primary` styling with accent color

### Commands Run

- ./scripts/lint.sh ✓

### Next

- Task 8: Add minimal top navigation anchors

---

## Task 8: Add minimal top navigation anchors

**Thread**: https://ampcode.com/threads/T-019c25a5-f588-721b-a09c-c0f878b50860
**Status**: completed
**Iteration**: 2

### Changes

- `site/index.html` - Added nav with anchor links (Install · What you get · Workflow · Docs), added IDs to sections
- `site/style.css` - Added smooth scroll, nav styling

### Commands Run

- ./scripts/lint.sh ✓

### Outcome

All 8 tasks completed.

---

