# Sample Skill

A test skill for fixture purposes.

## Usage

Use this skill when testing.
