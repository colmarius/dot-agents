# Sample skill
