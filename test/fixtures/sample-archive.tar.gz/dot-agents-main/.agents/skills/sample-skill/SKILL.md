---
name: sample-skill
description: A sample skill for testing
---

# Sample Skill

This is a sample skill used for testing the installation process.
